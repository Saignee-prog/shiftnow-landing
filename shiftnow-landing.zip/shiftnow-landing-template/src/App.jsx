import { useState } from 'react'

export default function App() {
  const [email, setEmail] = useState("")

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(to bottom right, #f3e5f5, #ffe0b2)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem'
    }}>
      <h1 style={{ fontSize: '3rem', color: '#6a1b9a' }}>ShiftNow</h1>
      <p style={{ textAlign: 'center', maxWidth: '500px', color: '#4a148c' }}>
        La solution rapide pour trouver ou proposer un remplacement dans l'Horeca.
      </p>
      <div style={{
        background: '#fff',
        padding: '2rem',
        borderRadius: '1rem',
        marginTop: '2rem',
        boxShadow: '0 5px 20px rgba(0,0,0,0.1)',
        width: '100%',
        maxWidth: '400px'
      }}>
        <p style={{ marginBottom: '1rem', color: '#333', fontWeight: '500' }}>
          Recevez un accès anticipé et 3 mois gratuits
        </p>
        <input
          type="email"
          placeholder="Votre email professionnel"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{
            padding: '0.75rem',
            width: '100%',
            borderRadius: '0.5rem',
            border: '1px solid #ccc',
            marginBottom: '1rem'
          }}
        />
        <button style={{
          backgroundColor: '#8e24aa',
          color: 'white',
          padding: '0.75rem',
          width: '100%',
          borderRadius: '0.5rem',
          border: 'none'
        }}>
          Je m'inscris
        </button>
      </div>
    </div>
  )
}
